<script setup>
import { computed, onMounted, ref } from 'vue'

const API_BASE = import.meta.env.VITE_API_BASE_URL || ''
const demoMode = ref(!API_BASE)
const activePage = ref('dashboard')
const loading = ref(false)
const toast = ref('')
const toastType = ref('success')
const modal = ref('')
const editingEquipmentId = ref(null)
const loginEmail = ref('manager@toir-prof.ru')
const loginPassword = ref('demo123')
const isAuthenticated = ref(false)
const loginError = ref('')
const searchEquipment = ref('')
const equipmentStatusFilter = ref('Все статусы')
const equipmentSort = ref('name')
const requestStatusFilter = ref('Все статусы')
const requestPriorityFilter = ref('Все приоритеты')
const searchRequests = ref('')
const newEquipment = ref({ name: '', type: '', location: '', status: 'Работает' })
const newRequest = ref({ equipmentId: '', type: 'Плановое обслуживание', priority: 'Средний', description: '' })

const equipment = ref([
  { id: 101, name: 'Компрессор К-12', type: 'Компрессор', location: 'Цех №1', status: 'Работает', updated: '26.10.2026' },
  { id: 102, name: 'Насос Н-04', type: 'Насосное оборудование', location: 'Цех №2', status: 'На обслуживании', updated: '25.10.2026' },
  { id: 103, name: 'Станок ФР-7', type: 'Фрезерный станок', location: 'Цех №1', status: 'Неисправно', updated: '24.10.2026' },
  { id: 104, name: 'Вентиляция В-2', type: 'Вентиляция', location: 'Склад', status: 'Работает', updated: '22.10.2026' },
  { id: 105, name: 'Котёл КВ-8', type: 'Котельное оборудование', location: 'Котельная', status: 'Работает', updated: '21.10.2026' },
  { id: 106, name: 'Конвейер Л-3', type: 'Конвейер', location: 'Цех №3', status: 'Неисправно', updated: '20.10.2026' }
])
const requests = ref([
  { id: 'З-2048', equipmentId: 103, type: 'Ремонт', priority: 'Высокий', status: 'В работе', description: 'Посторонний шум при запуске', date: '28.10.2026' },
  { id: 'З-2047', equipmentId: 102, type: 'Плановое обслуживание', priority: 'Средний', status: 'Ожидает', description: 'Плановая проверка узлов', date: '27.10.2026' },
  { id: 'З-2046', equipmentId: 106, type: 'Ремонт', priority: 'Высокий', status: 'Ожидает', description: 'Остановка конвейерной ленты', date: '27.10.2026' },
  { id: 'З-2045', equipmentId: 101, type: 'Осмотр', priority: 'Низкий', status: 'Завершена', description: 'Осмотр перед сменой', date: '26.10.2026' },
  { id: 'З-2044', equipmentId: 104, type: 'Плановое обслуживание', priority: 'Средний', status: 'Завершена', description: 'Замена фильтров', date: '25.10.2026' }
])

const equipmentName = id => equipment.value.find(item => item.id === Number(id))?.name || 'Оборудование удалено'
const workingCount = computed(() => equipment.value.filter(item => item.status === 'Работает').length)
const activeRequests = computed(() => requests.value.filter(item => item.status !== 'Завершена').length)
const downtimeCount = computed(() => equipment.value.filter(item => item.status === 'Неисправно').length)
const statusCounts = computed(() => [
  { label: 'Работает', count: equipment.value.filter(x => x.status === 'Работает').length, color: '#2db88b' },
  { label: 'На обслуживании', count: equipment.value.filter(x => x.status === 'На обслуживании').length, color: '#f2b84b' },
  { label: 'Неисправно', count: equipment.value.filter(x => x.status === 'Неисправно').length, color: '#ef6b73' }
])
const totalStatus = computed(() => Math.max(1, equipment.value.length))
const filteredEquipment = computed(() => {
  const term = searchEquipment.value.toLowerCase().trim()
  return equipment.value.filter(item => {
    const matchesSearch = `${item.name} ${item.type} ${item.location}`.toLowerCase().includes(term)
    const matchesStatus = equipmentStatusFilter.value === 'Все статусы' || item.status === equipmentStatusFilter.value
    return matchesSearch && matchesStatus
  }).sort((a, b) => {
    if (equipmentSort.value === 'status') return a.status.localeCompare(b.status, 'ru')
    if (equipmentSort.value === 'location') return a.location.localeCompare(b.location, 'ru')
    return a.name.localeCompare(b.name, 'ru')
  })
})
const filteredRequests = computed(() => {
  const term = searchRequests.value.toLowerCase().trim()
  return requests.value.filter(item => {
    const haystack = `${item.id} ${equipmentName(item.equipmentId)} ${item.description}`.toLowerCase()
    const statusMatch = requestStatusFilter.value === 'Все статусы' || item.status === requestStatusFilter.value
    const priorityMatch = requestPriorityFilter.value === 'Все приоритеты' || item.priority === requestPriorityFilter.value
    return haystack.includes(term) && statusMatch && priorityMatch
  })
})
const recentRequests = computed(() => [...requests.value].slice(0, 4))

function notify(message, type = 'success') {
  toast.value = message
  toastType.value = type
  window.setTimeout(() => { if (toast.value === message) toast.value = '' }, 3200)
}
async function apiRequest(path, options = {}) {
  if (demoMode.value) return null
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), 10000)
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    })
    if (response.status === 401) {
      isAuthenticated.value = false
      throw new Error('Сессия завершена. Войдите снова.')
    }
    if (!response.ok) throw new Error(response.status === 500 ? 'Ошибка сервера. Попробуйте позже.' : `Ошибка запроса: ${response.status}`)
    return response.status === 204 ? null : await response.json()
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Сервер не ответил вовремя. Проверьте соединение.')
    if (error instanceof TypeError) throw new Error('Сервер недоступен. Проверьте подключение к сети.')
    throw error
  } finally {
    window.clearTimeout(timeout)
  }
}
async function login() {
  loginError.value = ''
  if (!loginEmail.value.trim() || !loginPassword.value) {
    loginError.value = 'Введите email и пароль.'
    return
  }
  loading.value = true
  try {
    if (!demoMode.value) {
      await apiRequest('/auth/login', { method: 'POST', body: JSON.stringify({ email: loginEmail.value, password: loginPassword.value }) })
    }
    isAuthenticated.value = true
    notify(demoMode.value ? 'Демонстрационный вход выполнен' : 'Вы успешно вошли')
  } catch (error) {
    loginError.value = error.message
  } finally {
    loading.value = false
  }
}
function logout() {
  isAuthenticated.value = false
  activePage.value = 'dashboard'
  loginPassword.value = ''
}
function openNewEquipment() {
  editingEquipmentId.value = null
  newEquipment.value = { name: '', type: '', location: '', status: 'Работает' }
  modal.value = 'equipment'
}
function editEquipment(item) {
  editingEquipmentId.value = item.id
  newEquipment.value = { name: item.name, type: item.type, location: item.location, status: item.status }
  modal.value = 'equipment'
}
async function saveEquipment() {
  if (!newEquipment.value.name.trim() || !newEquipment.value.type.trim() || !newEquipment.value.location.trim()) {
    notify('Заполните все поля оборудования', 'error')
    return
  }
  loading.value = true
  try {
    if (editingEquipmentId.value) {
      const item = equipment.value.find(x => x.id === editingEquipmentId.value)
      Object.assign(item, newEquipment.value, { updated: '28.10.2026' })
      if (!demoMode.value) await apiRequest(`/equipment/${item.id}`, { method: 'PUT', body: JSON.stringify(newEquipment.value) })
      notify('Оборудование обновлено')
    } else {
      const item = { id: Math.max(100, ...equipment.value.map(x => x.id)) + 1, ...newEquipment.value, updated: '28.10.2026' }
      if (!demoMode.value) await apiRequest('/equipment', { method: 'POST', body: JSON.stringify(newEquipment.value) })
      equipment.value.unshift(item)
      notify('Оборудование добавлено')
    }
    modal.value = ''
  } catch (error) {
    notify(error.message, 'error')
  } finally {
    loading.value = false
  }
}
function deleteEquipment(item) {
  if (requests.value.some(r => r.equipmentId === item.id && r.status !== 'Завершена')) {
    notify('Нельзя удалить оборудование с активными заявками', 'error')
    return
  }
  if (window.confirm(`Удалить «${item.name}»?`)) {
    equipment.value = equipment.value.filter(x => x.id !== item.id)
    notify('Оборудование удалено')
  }
}
function openNewRequest() {
  newRequest.value = { equipmentId: equipment.value[0]?.id || '', type: 'Плановое обслуживание', priority: 'Средний', description: '' }
  modal.value = 'request'
}
async function saveRequest() {
  if (!newRequest.value.equipmentId || !newRequest.value.description.trim()) {
    notify('Выберите оборудование и укажите описание', 'error')
    return
  }
  const item = {
    id: `З-${2049 + requests.value.length}`,
    equipmentId: Number(newRequest.value.equipmentId),
    type: newRequest.value.type,
    priority: newRequest.value.priority,
    status: 'Ожидает',
    description: newRequest.value.description.trim(),
    date: '28.10.2026'
  }
  loading.value = true
  try {
    if (!demoMode.value) await apiRequest('/requests', { method: 'POST', body: JSON.stringify(newRequest.value) })
    requests.value.unshift(item)
    modal.value = ''
    notify('Заявка создана')
  } catch (error) {
    notify(error.message, 'error')
  } finally {
    loading.value = false
  }
}
function cycleRequestStatus(item) {
  const next = { 'Ожидает': 'В работе', 'В работе': 'Завершена', 'Завершена': 'Ожидает' }
  item.status = next[item.status]
  notify(`Статус заявки ${item.id}: ${item.status}`)
}
function exportCsv() {
  const rows = [['ID', 'Оборудование', 'Тип', 'Приоритет', 'Статус', 'Описание', 'Дата'], ...filteredRequests.value.map(r => [r.id, equipmentName(r.equipmentId), r.type, r.priority, r.status, r.description, r.date])]
  const csv = '\uFEFF' + rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(';')).join('\r\n')
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }))
  const link = document.createElement('a')
  link.href = url
  link.download = 'toir-requests.csv'
  link.click()
  URL.revokeObjectURL(url)
  notify('Список заявок экспортирован')
}
onMounted(async () => {
  if (!demoMode.value) {
    loading.value = true
    try {
      const [equipmentData, requestData] = await Promise.all([apiRequest('/equipment'), apiRequest('/requests')])
      if (equipmentData) equipment.value = equipmentData
      if (requestData) requests.value = requestData
    } catch (error) {
      notify(error.message, 'error')
    } finally {
      loading.value = false
    }
  }
})
</script>

<template>
  <main v-if="!isAuthenticated" class="login-screen">
    <div class="login-decoration"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="login-grid"></div></div>
    <section class="login-card">
      <div class="brand brand-login"><div class="brand-mark"><span></span><span></span><span></span></div><div><strong>ТОиР-Проф</strong><small>Управление обслуживанием</small></div></div>
      <p class="eyebrow">ПАНЕЛЬ УПРАВЛЕНИЯ</p>
      <h1>Добро пожаловать</h1>
      <p class="muted">Войдите, чтобы посмотреть состояние оборудования и заявки на обслуживание.</p>
      <form @submit.prevent="login" class="login-form">
        <label>Email<input v-model="loginEmail" type="email" placeholder="name@company.ru" autocomplete="username" /></label>
        <label>Пароль<input v-model="loginPassword" type="password" placeholder="Введите пароль" autocomplete="current-password" /></label>
        <p v-if="loginError" class="form-error">{{ loginError }}</p>
        <button class="button primary full" type="submit" :disabled="loading">{{ loading ? 'Выполняется вход…' : 'Войти в систему <' }}</button>
      </form>
      <div class="demo-note"><span class="status-dot"></span><span><b>Демонстрационный режим</b><br />Email и пароль можно оставить как есть.</span></div>
      <div class="login-footer">ТОиР-Проф · Версия 1.0</div>
    </section>
  </main>

  <div v-else class="app-shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark"><span></span><span></span><span></span></div><div><strong>ТОиР-Проф</strong><small>Техническое обслуживание</small></div></div>
      <div class="nav-label">РАБОЧЕЕ ПРОСТРАНСТВО</div>
      <nav>
        <button :class="{ active: activePage === 'dashboard' }" @click="activePage = 'dashboard'"><span class="nav-icon">▦</span>Обзор</button>
        <button :class="{ active: activePage === 'equipment' }" @click="activePage = 'equipment'"><span class="nav-icon">▤</span>Оборудование <span class="nav-count">{{ equipment.length }}</span></button>
        <button :class="{ active: activePage === 'requests' }" @click="activePage = 'requests'"><span class="nav-icon">☷</span>Заявки <span class="nav-count">{{ activeRequests }}</span></button>
      </nav>
      <div class="sidebar-bottom">
        <div class="server-card"><div class="server-top"><span class="status-dot"></span><b>{{ demoMode ? 'Демо-режим' : 'Подключение к API' }}</b></div><p>{{ demoMode ? 'Показаны тестовые данные' : 'Данные загружаются с сервера' }}</p><span class="server-link" @click="notify(demoMode ? 'Укажите VITE_API_BASE_URL для подключения сервера' : 'REST API настроен')">Настройки подключения ↗</span></div>
        <div class="user-profile"><div class="avatar">Я</div><div class="user-details"><b>Я. А. Дудник</b><small>Руководитель ТОиР</small></div><button class="logout" title="Выйти" @click="logout">↗</button></div>
      </div>
    </aside>

    <section class="main-area">
      <header class="topbar"><div class="breadcrumb">ТОиР-Проф <span>/</span> <b>{{ activePage === 'dashboard' ? 'Обзор' : activePage === 'equipment' ? 'Оборудование' : 'Заявки' }}</b></div><div class="top-actions"><span class="live-status"><i></i>{{ loading ? 'Загрузка данных' : 'Система активна' }}</span><button class="icon-button" title="Уведомления" @click="notify('Новых уведомлений нет')">♧<span class="notification-dot"></span></button><div class="top-date">28 окт. 2026</div></div></header>
      <div class="page-content">
        <div v-if="activePage === 'dashboard'">
          <div class="page-heading"><div><p class="eyebrow">СРЕДА, 28 ОКТЯБРЯ 2026</p><h1>Обзор состояния</h1><p class="muted">Сводная информация по техническому обслуживанию предприятия.</p></div><button class="button primary" @click="openNewRequest"><span>＋</span> Создать заявку</button></div>
          <div class="kpi-grid">
            <article class="kpi-card"><div class="kpi-top"><span>Всего оборудования</span><span class="kpi-icon blue">▤</span></div><div class="kpi-value">{{ equipment.length }}<small>ед.</small></div><div class="kpi-bottom"><span class="mini-bar blue-bar"></span><span>В реестре предприятия</span></div></article>
            <article class="kpi-card"><div class="kpi-top"><span>Активные заявки</span><span class="kpi-icon amber">☷</span></div><div class="kpi-value">{{ activeRequests }}<small>шт.</small></div><div class="kpi-bottom"><span class="trend amber-text">●</span><span>Требуют внимания</span></div></article>
            <article class="kpi-card"><div class="kpi-top"><span>Простой оборудования</span><span class="kpi-icon red">◷</span></div><div class="kpi-value">{{ downtimeCount }}<small>ед.</small></div><div class="kpi-bottom"><span class="trend red-text">●</span><span>Неисправно на данный момент</span></div></article>
            <article class="kpi-card"><div class="kpi-top"><span>В рабочем состоянии</span><span class="kpi-icon green">✓</span></div><div class="kpi-value">{{ workingCount }}<small>ед.</small></div><div class="kpi-bottom"><span class="mini-bar green-bar"></span><span>{{ Math.round(workingCount / Math.max(1, equipment.length) * 100) }}% от общего количества</span></div></article>
          </div>
          <div class="dashboard-grid">
            <article class="panel status-panel"><div class="panel-heading"><div><h2>Состояние оборудования</h2><p>Распределение по текущим статусам</p></div><span class="subtle-pill">В реальном времени</span></div><div class="chart-content"><div class="donut-wrap"><svg viewBox="0 0 160 160" class="donut"><circle cx="80" cy="80" r="59" fill="none" stroke="#edf1f6" stroke-width="18"/><circle v-for="(item, index) in statusCounts" :key="item.label" cx="80" cy="80" r="59" fill="none" :stroke="item.color" stroke-width="18" stroke-linecap="round" :stroke-dasharray="`${item.count / totalStatus * 370} ${370 - item.count / totalStatus * 370}`" :stroke-dashoffset="-(statusCounts.slice(0, index).reduce((sum, s) => sum + s.count / totalStatus * 370, 0))" transform="rotate(-90 80 80)"/></svg><div class="donut-center"><strong>{{ equipment.length }}</strong><span>единиц</span></div></div><div class="legend"><div v-for="item in statusCounts" :key="item.label" class="legend-row"><span class="legend-dot" :style="{ background: item.color }"></span><span>{{ item.label }}</span><b>{{ item.count }}</b><small>{{ Math.round(item.count / totalStatus * 100) }}%</small></div></div></div></article>
            <article class="panel quick-panel"><div class="panel-heading"><div><h2>Быстрые действия</h2><p>Часто используемые операции</p></div></div><button class="quick-action" @click="openNewEquipment"><span class="quick-icon blue">＋</span><span><b>Добавить оборудование</b><small>Внести новую единицу в реестр</small></span><span class="arrow">→</span></button><button class="quick-action" @click="openNewRequest"><span class="quick-icon amber">↗</span><span><b>Создать заявку</b><small>Сообщить о неисправности или осмотре</small></span><span class="arrow">→</span></button><button class="quick-action" @click="activePage = 'equipment'"><span class="quick-icon green">▤</span><span><b>Открыть реестр</b><small>Просмотреть всё оборудование</small></span><span class="arrow">→</span></button></article>
          </div>
          <article class="panel recent-panel"><div class="panel-heading"><div><h2>Последние заявки</h2><p>Актуальные обращения по обслуживанию</p></div><button class="text-button" @click="activePage = 'requests'">Все заявки <span>→</span></button></div><div class="table-scroll"><table><thead><tr><th>Номер</th><th>Оборудование</th><th>Тип заявки</th><th>Приоритет</th><th>Статус</th><th>Дата</th></tr></thead><tbody><tr v-for="item in recentRequests" :key="item.id"><td><b class="request-id">{{ item.id }}</b></td><td><span class="equipment-cell"><span class="equip-mini">▤</span>{{ equipmentName(item.equipmentId) }}</span></td><td>{{ item.type }}</td><td><span class="priority" :class="item.priority.toLowerCase()"><i></i>{{ item.priority }}</span></td><td><span class="status-badge" :class="item.status === 'Завершена' ? 'done' : item.status === 'В работе' ? 'in-progress' : 'waiting'">{{ item.status }}</span></td><td class="muted-cell">{{ item.date }}</td></tr></tbody></table></div></article>
        </div>

        <div v-else-if="activePage === 'equipment'">
          <div class="page-heading"><div><p class="eyebrow">РЕЕСТР ПРЕДПРИЯТИЯ</p><h1>Оборудование</h1><p class="muted">Управляйте оборудованием и отслеживайте его состояние.</p></div><button class="button primary" @click="openNewEquipment"><span>＋</span> Добавить оборудование</button></div>
          <div class="filter-bar"><label class="search-field"><span>⌕</span><input v-model="searchEquipment" placeholder="Поиск по названию, типу или месту..." /></label><select v-model="equipmentStatusFilter"><option>Все статусы</option><option>Работает</option><option>На обслуживании</option><option>Неисправно</option></select><select v-model="equipmentSort"><option value="name">Сортировка: по названию</option><option value="status">Сортировка: по статусу</option><option value="location">Сортировка: по месту</option></select><span class="results-count">{{ filteredEquipment.length }} записей</span></div>
          <article class="panel table-panel"><div class="table-scroll"><table><thead><tr><th>Оборудование</th><th>Тип</th><th>Расположение</th><th>Статус</th><th>Обновлено</th><th>Действия</th></tr></thead><tbody><tr v-for="item in filteredEquipment" :key="item.id"><td><span class="equipment-cell"><span class="equip-mini">▤</span><span><b>{{ item.name }}</b><small class="cell-sub">ID: {{ item.id }}</small></span></span></td><td>{{ item.type }}</td><td>{{ item.location }}</td><td><span class="status-badge" :class="item.status === 'Работает' ? 'done' : item.status === 'Неисправно' ? 'broken' : 'waiting'">{{ item.status }}</span></td><td class="muted-cell">{{ item.updated }}</td><td><div class="row-actions"><button title="Редактировать" @click="editEquipment(item)">✎</button><button title="Удалить" @click="deleteEquipment(item)">×</button></div></td></tr><tr v-if="!filteredEquipment.length"><td colspan="6" class="empty-state">Ничего не найдено. Измените параметры поиска.</td></tr></tbody></table></div><div class="table-footer">Показано {{ filteredEquipment.length }} из {{ equipment.length }} единиц оборудования</div></article>
        </div>

        <div v-else>
          <div class="page-heading"><div><p class="eyebrow">ОБСЛУЖИВАНИЕ И РЕМОНТ</p><h1>Заявки</h1><p class="muted">Контролируйте обращения, приоритеты и ход выполнения работ.</p></div><div class="heading-actions"><button class="button secondary" @click="exportCsv">↓ Экспорт CSV</button><button class="button primary" @click="openNewRequest"><span>＋</span> Создать заявку</button></div></div>
          <div class="filter-bar"><label class="search-field"><span>⌕</span><input v-model="searchRequests" placeholder="Поиск по номеру, оборудованию..." /></label><select v-model="requestStatusFilter"><option>Все статусы</option><option>Ожидает</option><option>В работе</option><option>Завершена</option></select><select v-model="requestPriorityFilter"><option>Все приоритеты</option><option>Высокий</option><option>Средний</option><option>Низкий</option></select><span class="results-count">{{ filteredRequests.length }} заявок</span></div>
          <article class="panel table-panel"><div class="table-scroll"><table><thead><tr><th>Номер</th><th>Оборудование</th><th>Тип заявки</th><th>Приоритет</th><th>Описание</th><th>Статус</th><th>Дата</th><th></th></tr></thead><tbody><tr v-for="item in filteredRequests" :key="item.id"><td><b class="request-id">{{ item.id }}</b></td><td>{{ equipmentName(item.equipmentId) }}</td><td>{{ item.type }}</td><td><span class="priority" :class="item.priority.toLowerCase()"><i></i>{{ item.priority }}</span></td><td class="description-cell">{{ item.description }}</td><td><button class="status-badge status-click" :class="item.status === 'Завершена' ? 'done' : item.status === 'В работе' ? 'in-progress' : 'waiting'" @click="cycleRequestStatus(item)" title="Нажмите, чтобы изменить статус">{{ item.status }}</button></td><td class="muted-cell">{{ item.date }}</td><td><button class="more-button" title="Изменить статус" @click="cycleRequestStatus(item)">···</button></td></tr><tr v-if="!filteredRequests.length"><td colspan="8" class="empty-state">Заявок по выбранным условиям нет.</td></tr></tbody></table></div><div class="table-footer">Нажмите на статус заявки, чтобы переключить состояние.</div></article>
          <div class="hint-box"><span>ⓘ</span><p><b>Подсказка:</b> приоритет помогает определить очередность работ. Заявки с высоким приоритетом требуют первоочередного внимания.</p></div>
        </div>
        <footer class="page-footer"><span>© 2026 ТОиР-Проф</span><span>Система управления техническим обслуживанием</span><span><i></i> {{ demoMode ? 'Демонстрационные данные' : 'REST API' }}</span></footer>
      </div>
    </section>

    <div v-if="modal" class="modal-backdrop" @click.self="modal = ''">
      <section class="modal-card">
        <div class="modal-heading"><div><p class="eyebrow">{{ modal === 'equipment' ? 'РЕЕСТР ОБОРУДОВАНИЯ' : 'ОБСЛУЖИВАНИЕ' }}</p><h2>{{ modal === 'equipment' ? (editingEquipmentId ? 'Редактировать оборудование' : 'Новое оборудование') : 'Новая заявка' }}</h2></div><button class="modal-close" @click="modal = ''">×</button></div>
        <form v-if="modal === 'equipment'" @submit.prevent="saveEquipment" class="modal-form">
          <label>Название оборудования<input v-model="newEquipment.name" required placeholder="Например, Насос Н-10" /></label>
          <label>Тип оборудования<input v-model="newEquipment.type" required placeholder="Например, Насосное оборудование" /></label>
          <label>Расположение<input v-model="newEquipment.location" required placeholder="Например, Цех №1" /></label>
          <label>Текущий статус<select v-model="newEquipment.status"><option>Работает</option><option>На обслуживании</option><option>Неисправно</option></select></label>
          <div class="modal-actions"><button type="button" class="button secondary" @click="modal = ''">Отмена</button><button class="button primary" type="submit" :disabled="loading">{{ loading ? 'Сохранение…' : 'Сохранить' }}</button></div>
        </form>
        <form v-else @submit.prevent="saveRequest" class="modal-form">
          <label>Оборудование<select v-model="newRequest.equipmentId" required><option disabled value="">Выберите оборудование</option><option v-for="item in equipment" :key="item.id" :value="item.id">{{ item.name }}</option></select></label>
          <label>Тип заявки<select v-model="newRequest.type"><option>Плановое обслуживание</option><option>Ремонт</option><option>Осмотр</option></select></label>
          <label>Приоритет<select v-model="newRequest.priority"><option>Высокий</option><option>Средний</option><option>Низкий</option></select></label>
          <label>Описание проблемы или работ<textarea v-model="newRequest.description" required rows="3" placeholder="Опишите неисправность или необходимые работы..."></textarea></label>
          <div class="modal-actions"><button type="button" class="button secondary" @click="modal = ''">Отмена</button><button class="button primary" type="submit" :disabled="loading">{{ loading ? 'Создание…' : 'Создать заявку' }}</button></div>
        </form>
      </section>
    </div>
    <div v-if="toast" class="toast" :class="toastType"><span>{{ toastType === 'error' ? '!' : '✓' }}</span>{{ toast }}</div>
  </div>
</template>